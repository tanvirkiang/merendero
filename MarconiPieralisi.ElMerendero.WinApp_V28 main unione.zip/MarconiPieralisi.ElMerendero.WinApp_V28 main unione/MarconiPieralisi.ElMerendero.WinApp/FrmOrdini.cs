﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarconiPieralisi.ElMerendero.WinApp
{
    public partial class FrmOrdini : Form
    {
        public FrmOrdini()
        {
            InitializeComponent();
        }

        List<ClsClasse> lclassi;
        List<ClsOrdini> lOrdini;
        private void btnAvanza_Click(object sender, EventArgs e)
        {
            //devi fare update dell'ordine, cambiando solo stato ordine
        }

        private void cmbClasse_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbProdotto_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void Stampa()//stampare le classi
        {
            ClsClasse classe = new ClsClasse();
            lclassi = classe.GetClassi("");
            cmbClasse.Items.Clear();
            if (lclassi != null)
            {
                for (int i = 0; i < lclassi.Count; i++)
                {
                    cmbClasse.Items.Add(lclassi[i].Sigla);
                }
            }

        }
        private void btnOrdine_Click(object sender, EventArgs e)
        {
            FrmOrdine f = new FrmOrdine();
            this.Hide();
            f.Show();
        }

        private void btnAggiorna_Click(object sender, EventArgs e)
        {

           
            if (cmbClasse.SelectedItem == null)
            {
               
                ClsOrdini ordine = new ClsOrdini();
                lOrdini = ordine.getOrdini("");
            }
            else
            {

                ClsOrdini ordine = new ClsOrdini();
                string selez = cmbClasse.SelectedItem.ToString();
                lOrdini = ordine.getOrdini(selez);
            }
        }

        private void FrmOrdini_Load(object sender, EventArgs e)
        {
            //Program.clsClasse = new ClsClasse();
            //List<ClsClasse> classi = Program.clsClasse.GetClassi();

            //user control
            UcButtons ucb = new UcButtons();
            ucb.Dock = DockStyle.Left; // Per riempire lo spazio di sinistra
            ucb.BringToFront();  // Per portare i bottoni in primo piano
            this.Controls.Add(ucb); // Per aggiungere lo usercontrol alla form
            panel2.SendToBack(); // Per assicurarsi che lo usercontrol non finisca sopra al panello del titolo

            //ClsClasse classe = new ClsClasse();
            //lclassi = classe.GetClassi("");
            //lstProdotti.Items.Clear();
            //for (int i = 0; i < lclassi.Count; i++)
            //{
            //    ListViewItem lista = new ListViewItem(lclassi[i].);
            //    lista.SubItems.Add(Convert.ToString(lclassi[i].Sezione));
            //    lista.SubItems.Add(Convert.ToString(lclassi[i].));
            //    lstProdotti.Items.Add(lista);
            //}
            ClsOrdini ordine = new ClsOrdini();
            lOrdini = ordine.getOrdini("");
            lstProdotti.Items.Clear();
            for (int i = 0; i < lclassi.Count; i++)
            {
                ListViewItem lista = new ListViewItem(lOrdini[i].Nomeprodotto);
                lista.SubItems.Add(Convert.ToString(lOrdini[i].Classe));
                lista.SubItems.Add(Convert.ToString(lOrdini[i].Stato));
                lstProdotti.Items.Add(lista);
            }
            Stampa();
        }
    }
}
