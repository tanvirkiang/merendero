﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace MarconiPieralisi.ElMerendero.WinApp
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
           
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {

        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            //this.Close();
            Application.Exit();
        }
       
        private void btnlogin_Click(object sender, EventArgs e)
        {
            //FrmAdministrator f = new FrmAdministrator();
            //this.Hide();
            //f.Show();

            //Program.SetCredenziali("", "");
            Program._credenziale.UserType= 'A';//SHIFAT: st7976 è S MA SIAMO ANCORA IN FASE DI SVILUPPO QUINDI PER MOSTRARE TUTTI I BOTTONI DI USER CONTROL HO MESSO A
            Program.SetCredenziali("st7976@iismarconipieralisi.it", ""); 

              FrmUtentiAdm f = new FrmUtentiAdm();          
            this.Hide();
            f.Show();

            //FrmProdotti f = new FrmProdotti();
            //this.Hide();
            //f.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            
        }
    }
}
