﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using System.Net;

namespace MarconiPieralisi.ElMerendero.WinApp
{
    public partial class FrmProdotti :Form
    {
        public FrmProdotti()
        {
            InitializeComponent();
            UcButtons ucb = new UcButtons();
            ucb.Dock = DockStyle.Left; // Per riempire lo spazio di sinistra
            ucb.BringToFront();  // Per portare i bottoni in primo piano
            this.Controls.Add(ucb); // Per aggiungere lo usercontrol alla form
            panel2.SendToBack(); // Per assicurarsi che lo usercontrol non finisca sopra al panello del titolo
            disattiva();          
            loadCategoria();
        }
        ClsProdotto prodotto = new ClsProdotto();
        bool edit=false;

        private void loadProdotti()
        {
            string nomecategoria;
            ClsProdotto prodotto = new ClsProdotto();
            if (cmbcategoria2.SelectedItem==null)
            {
                nomecategoria = "";
            }
            else
            {
                nomecategoria = cmbcategoria2.SelectedItem.ToString();
            }
            List<ClsProdotto> prodotti = prodotto.getProdotti(nomecategoria);

            lsvprodotti.Items.Clear();
            if (prodotti!=null)
            {
                foreach (ClsProdotto item in prodotti)
                {
                    ListViewItem lvi = new ListViewItem(item.Nome);
                    lvi.SubItems.Add(Convert.ToString(item.Quantita));
                    lvi.SubItems.Add(item.Descrizione);
                    lvi.SubItems.Add(Convert.ToString(item.Prezzo));
                    lsvprodotti.Items.Add(lvi);
                }
            }
            
        }
        private void loadCategoria()
        {

            ClsCategoria categoria = new ClsCategoria();
            List<ClsCategoria> categorie = categoria.getCategorie();

            cmbcategoria.Items.Clear();
            cmbcategoria2.Items.Clear();
            if (categorie!=null)
            {
                foreach (ClsCategoria item in categorie)
                {
                    cmbcategoria.Items.Add(item.nome);
                    cmbcategoria2.Items.Add(item.nome);
                }
            }
            
        }
        private void attiva()
        {
            txtnomeprodotto.Enabled = true;
            numQuantità.Enabled = true;
            txtdescrizione.Enabled = true;
            numPrezzo.Enabled = true;
            cmbcategoria.Enabled = true;
        }
        private void disattiva()
        {
            txtnomeprodotto.Enabled = false;
            numQuantità.Enabled = false;
            txtdescrizione.Enabled = false;
            numPrezzo.Enabled = false;
            cmbcategoria.Enabled = false;
        }
        
        private void btnaggiungi_Click(object sender, EventArgs e)
        {
            attiva();
            edit = false;
            loadProdotti();
        }

        private void btnmodifica_Click(object sender, EventArgs e)
        {
            attiva();            
            edit = true;
            if (lsvprodotti.SelectedIndices.Count == 1)
            {
                int indiceSelezionato = lsvprodotti.SelectedIndices[0];
                if (indiceSelezionato >= 0)
                {
                    prodotto.Nome = txtnomeprodotto.Text;
                    prodotto.Quantita = Convert.ToInt32(numQuantità.Text);
                    prodotto.Descrizione = txtdescrizione.Text;
                    prodotto.Prezzo = Convert.ToSingle(numPrezzo.Text);
                    prodotto.NomeCategoria = cmbcategoria.Text;
                }
            }
            else
            {
                MessageBox.Show(" ");
            }
            
        }

        private void btnelimina_Click(object sender, EventArgs e)
        {
            if (lsvprodotti.SelectedItems.Count >= 1)
            {
                ClsProdotto prodotto = new ClsProdotto();
                prodotto.Nome = lsvprodotti.SelectedItems[0].Text;
                MessageBox.Show(prodotto.deleteProdotto());
                loadProdotti();
            }
        }

        private void btnaggiorna_Click(object sender, EventArgs e)
        {
            loadProdotti();
        }
        private void btnsalvautente_Click_1(object sender, EventArgs e)
        {
            
            try
            {
                prodotto.Nome = txtnomeprodotto.Text;
                prodotto.Quantita = Convert.ToInt32(numQuantità.Text);
                prodotto.Descrizione = txtdescrizione.Text;
                prodotto.Prezzo = Convert.ToSingle(numPrezzo.Text);
                prodotto.NomeCategoria = cmbcategoria.Text;
                if (edit == false)
                {
                    string msg = prodotto.createProdotto();
                }
                else
                {
                    MessageBox.Show(prodotto.updateProdotto());
                    edit = false;
                }
                loadProdotti();
                disattiva();
            }
            catch (Exception)
            {
                MessageBox.Show("RICONTROLLA I CAMPI");
                throw;
            }
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            FrmUtentiAdm f = new FrmUtentiAdm();
            this.Hide();
            f.Show();
        }

        private void btnClassi_Click(object sender, EventArgs e)
        {

            FrmClassi f = new FrmClassi();
            this.Hide();
            f.Show();
        }

        private void btnalunni_Click(object sender, EventArgs e)
        {

            FrmUtentiAdm f = new FrmUtentiAdm();
            this.Hide();
            f.Show();
        }

        private void FrmProdotti_Load(object sender, EventArgs e)
        {

        }
    }
}
