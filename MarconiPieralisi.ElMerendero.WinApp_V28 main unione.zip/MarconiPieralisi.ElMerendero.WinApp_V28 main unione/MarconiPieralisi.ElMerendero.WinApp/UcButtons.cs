﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarconiPieralisi.ElMerendero.WinApp
{
    public partial class UcButtons : UserControl
    {
        public UcButtons()
        {
            InitializeComponent();
            btnOrdini.Visible = false;
            lbOrdini.Visible = false;
            btnUtenti.Visible = false;
            lbUtenti.Visible = false;
            btnClassi.Visible = false;
            lbClassi.Visible = false;
            btnProdotti.Visible = false;
            lbProd.Visible = false;
            btnOrdini.Visible = false;
            lbOrdini.Visible = false;
            btnOrdine.Visible = false;//possono vede gli studenti
            lbOrdine.Visible = false;//possono vede gli studenti
            btnPuntoVendita.Visible = false;
            lbPunto.Visible = false;
            btnCategoria.Visible = false;
            lbCat.Visible = false;

            //MessageBox.Show("" + log.tipoUtente);

            switch (Program._credenziale.UserType)
            {
                case 'S':
                    btnOrdine.Visible = true;//possono vede gli studenti
                    lbOrdine.Visible = true;//possono vede gli studenti
                    break;
                case 'P':
                    btnOrdine.Visible = true;//possono vede gli studenti
                    lbOrdine.Visible = true;//possono vede gli studenti
                    break;
                case 'M':
                    btnProdotti.Visible = true;
                    lbProd.Visible = true;
                    btnCategoria.Visible = true;
                    lbCat.Visible = true;                  
                    break;
                case 'A':
                    btnOrdini.Visible = true;
                    lbOrdini.Visible = true;
                    btnUtenti.Visible = true;
                    lbUtenti.Visible = true;
                    btnClassi.Visible = true;
                    lbClassi.Visible = true;
                    btnProdotti.Visible = true;
                    lbProd.Visible = true;
                    btnOrdini.Visible = true;
                    lbOrdini.Visible = true;
                    btnOrdine.Visible = true;//possono vede gli studenti
                    lbOrdine.Visible = true;//possono vede gli studenti
                    btnPuntoVendita.Visible = true;
                    lbPunto.Visible = true;
                    btnCategoria.Visible = true;
                    lbCat.Visible = true;
                    break;

            }
        }
        
        

        private void btnUtenti_Click(object sender, EventArgs e)
        {
            ParentForm.Close();
            FrmUtentiAdm f = new FrmUtentiAdm();
           
            f.Show();
        }

        private void btnOrdini_Click(object sender, EventArgs e)
        {

            ParentForm.Close();
            FrmOrdini f = new FrmOrdini();            
            f.Show();
        }

        private void btnClassi_Click(object sender, EventArgs e)
        {
            //string s = ParentForm.Name;
            //// Display the name in a message box.
            //MessageBox.Show("My Parent is " + s + ".");
            ParentForm.Close();
            FrmClassi f = new FrmClassi();
           
            f.Show();
        }

        private void btnProdotti_Click(object sender, EventArgs e)
        {
            ParentForm.Close();
            FrmProdotti f = new FrmProdotti();
            
            f.Show();
        }

        private void btnOrdine_Click(object sender, EventArgs e)
        {
            ParentForm.Close();
            FrmOrdine f = new FrmOrdine();
            
            f.Show();
        }

        private void pbxChiudi_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCategoria_Click(object sender, EventArgs e)
        {
            ParentForm.Close();
            FrmCategorie f = new FrmCategorie();

            f.Show();
        }
    }
}
