﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;

namespace MarconiPieralisi.ElMerendero.WinApp
{
    public partial class FrmCategorie : Form
    {
        #region VARIABILI GLOBALI

        List<ClsCategoria> categorie = new List<ClsCategoria>();
        ClsCategoria categoria;
        bool salvaOmodifica;
        bool modifica = false;

        #endregion

        public FrmCategorie()
        {
            InitializeComponent();
            UcButtons ucb = new UcButtons();
            ucb.Dock = DockStyle.Left; // Per riempire lo spazio di sinistra
            ucb.BringToFront();  // Per portare i bottoni in primo piano
            this.Controls.Add(ucb); // Per aggiungere lo usercontrol alla form
            panel2.SendToBack(); // Per assicurarsi che lo usercontrol non finisca sopra al panello del titolo
        }

        #region METODI

        private void mostraCampi()
        {
            tbNome.Enabled = true;
            btSalva.Enabled = true;
        }

        private void Aggiorna()
        {
            categorie = categoria.getCategorie();
            lvCategorie.Items.Clear();
            if (categorie != null)
            {
                foreach (ClsCategoria item in categorie)
                {
                    //ListViewItem lvi = new ListViewItem(item.nome);

                    lvCategorie.Items.Add(item.nome);
                }
            }
        }

        private void Pulisci()
        {
            tbNome.Clear();
            tbNome.Enabled = false;
        }

        #endregion

        private void btClose_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["FrmLogin"] != null)
            {
                Application.OpenForms["FrmLogin"].Show();
                this.Close();
            }
        }

        private void btAggiungi_Click(object sender, EventArgs e)
        {
            salvaOmodifica = true;
            mostraCampi();
        }

        private void btModifica_Click(object sender, EventArgs e)
        {
            salvaOmodifica = false;
            modifica = true;
            if (lvCategorie.SelectedIndices.Count == 1)
            {
                categoria = new ClsCategoria();
                string nomeCate = lvCategorie.SelectedItems[0].Tag.ToString();
                categoria = categorie.First(u => u.nome == nomeCate);
                tbNome.Text = categoria.nome;
                mostraCampi();
            }
            else
            {
                MessageBox.Show("Devi selezionare una riga dalla list view.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btElimina_Click(object sender, EventArgs e)
        {
            if (lvCategorie.SelectedIndices.Count == 1)
            {
                categoria = new ClsCategoria();
                string nomeCate = lvCategorie.SelectedItems[0].Tag.ToString();
                categoria = categorie.First(u => u.nome == nomeCate);
                DialogResult dr = MessageBox.Show("Sei sicuro di eliminare questoa categoria:" + categoria.nome + "?", "Attenzione", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dr == DialogResult.Yes)
                {
                    string msg = categoria.deleteCategoria();
                    MessageBox.Show(msg);
                    Aggiorna();
                }
            }
            else
            {
                MessageBox.Show("Devi selezionare una riga dalla list view.", "Attenzione", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btSalva_Click(object sender, EventArgs e)
        {
            bool erroreInserimento = false;
            string msg;
            ClsCategoria cate = new ClsCategoria();
            if (!modifica)
            {
                cate = new ClsCategoria();
            }
            else
            {
                cate = categoria;
            }
            if (tbNome.Text == "")
            {
                MessageBox.Show("Per inserire una categoria devi inserire il suo nome", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                erroreInserimento = true;
            }
            else
            {
                cate.nome = tbNome.Text;
            }

            if (!erroreInserimento)
            {
                if (salvaOmodifica)
                {
                    msg = cate.createCategoria();
                }
                else
                {
                    msg = cate.updateCategoria();
                }
                cate = new ClsCategoria();
                MessageBox.Show(msg);
                Aggiorna();
                modifica = false;
                Pulisci();
            }
            erroreInserimento = false;
        }

        private void FrmCategorie_Load(object sender, EventArgs e)
        {
           
        }
    }
}
