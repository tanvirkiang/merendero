﻿
namespace MarconiPieralisi.ElMerendero.WinApp
{
    partial class FrmProdotti
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmProdotti));
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtdescrizione = new System.Windows.Forms.TextBox();
            this.txtnomeprodotto = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblquantità = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnaggiorna = new System.Windows.Forms.Button();
            this.lsvprodotti = new System.Windows.Forms.ListView();
            this.tbnome = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tbquantità = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tbdescrizione = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tbprezzo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tbcategoria = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnelimina = new System.Windows.Forms.Button();
            this.btnmodifica = new System.Windows.Forms.Button();
            this.btnaggiungi = new System.Windows.Forms.Button();
            this.numQuantità = new System.Windows.Forms.NumericUpDown();
            this.numPrezzo = new System.Windows.Forms.NumericUpDown();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbcategoria = new System.Windows.Forms.ComboBox();
            this.cmbcategoria2 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btnsalvautente = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numQuantità)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPrezzo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.pictureBox3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(848, 91);
            this.panel2.TabIndex = 9;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(290, -68);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(232, 238);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(0, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(95, 91);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(621, 319);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 19);
            this.label4.TabIndex = 90;
            this.label4.Text = "Prezzo";
            // 
            // txtdescrizione
            // 
            this.txtdescrizione.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdescrizione.Location = new System.Drawing.Point(708, 288);
            this.txtdescrizione.Name = "txtdescrizione";
            this.txtdescrizione.Size = new System.Drawing.Size(100, 22);
            this.txtdescrizione.TabIndex = 89;
            // 
            // txtnomeprodotto
            // 
            this.txtnomeprodotto.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnomeprodotto.Location = new System.Drawing.Point(708, 222);
            this.txtnomeprodotto.Name = "txtnomeprodotto";
            this.txtnomeprodotto.Size = new System.Drawing.Size(100, 22);
            this.txtnomeprodotto.TabIndex = 87;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(584, 288);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 19);
            this.label3.TabIndex = 86;
            this.label3.Text = "Descrizione";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(624, 225);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 19);
            this.label2.TabIndex = 85;
            this.label2.Text = "Nome:";
            // 
            // lblquantità
            // 
            this.lblquantità.AutoSize = true;
            this.lblquantità.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblquantità.Location = new System.Drawing.Point(611, 258);
            this.lblquantità.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblquantità.Name = "lblquantità";
            this.lblquantità.Size = new System.Drawing.Size(73, 19);
            this.lblquantità.TabIndex = 84;
            this.lblquantità.Text = "Quantità";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(742, 419);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 19);
            this.label5.TabIndex = 83;
            this.label5.Text = "Salva";
            // 
            // btnaggiorna
            // 
            this.btnaggiorna.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaggiorna.Location = new System.Drawing.Point(310, 112);
            this.btnaggiorna.Name = "btnaggiorna";
            this.btnaggiorna.Size = new System.Drawing.Size(95, 33);
            this.btnaggiorna.TabIndex = 81;
            this.btnaggiorna.Text = "Aggiorna";
            this.btnaggiorna.UseVisualStyleBackColor = true;
            this.btnaggiorna.Click += new System.EventHandler(this.btnaggiorna_Click);
            // 
            // lsvprodotti
            // 
            this.lsvprodotti.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.tbnome,
            this.tbquantità,
            this.tbdescrizione,
            this.tbprezzo,
            this.tbcategoria});
            this.lsvprodotti.FullRowSelect = true;
            this.lsvprodotti.HideSelection = false;
            this.lsvprodotti.Location = new System.Drawing.Point(85, 153);
            this.lsvprodotti.Name = "lsvprodotti";
            this.lsvprodotti.Size = new System.Drawing.Size(320, 330);
            this.lsvprodotti.TabIndex = 77;
            this.lsvprodotti.UseCompatibleStateImageBehavior = false;
            this.lsvprodotti.View = System.Windows.Forms.View.Details;
            // 
            // tbnome
            // 
            this.tbnome.Text = "Nome";
            // 
            // tbquantità
            // 
            this.tbquantità.Text = "Quantità";
            // 
            // tbdescrizione
            // 
            this.tbdescrizione.Text = "Descrizione";
            this.tbdescrizione.Width = 72;
            // 
            // tbprezzo
            // 
            this.tbprezzo.Text = "Prezzo";
            // 
            // tbcategoria
            // 
            this.tbcategoria.Text = "Categoria";
            // 
            // btnelimina
            // 
            this.btnelimina.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnelimina.Location = new System.Drawing.Point(446, 343);
            this.btnelimina.Name = "btnelimina";
            this.btnelimina.Size = new System.Drawing.Size(95, 33);
            this.btnelimina.TabIndex = 80;
            this.btnelimina.Text = "Elimina";
            this.btnelimina.UseVisualStyleBackColor = true;
            this.btnelimina.Click += new System.EventHandler(this.btnelimina_Click);
            // 
            // btnmodifica
            // 
            this.btnmodifica.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmodifica.Location = new System.Drawing.Point(446, 273);
            this.btnmodifica.Name = "btnmodifica";
            this.btnmodifica.Size = new System.Drawing.Size(95, 33);
            this.btnmodifica.TabIndex = 79;
            this.btnmodifica.Text = "Modifica";
            this.btnmodifica.UseVisualStyleBackColor = true;
            this.btnmodifica.Click += new System.EventHandler(this.btnmodifica_Click);
            // 
            // btnaggiungi
            // 
            this.btnaggiungi.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaggiungi.Location = new System.Drawing.Point(446, 211);
            this.btnaggiungi.Name = "btnaggiungi";
            this.btnaggiungi.Size = new System.Drawing.Size(95, 33);
            this.btnaggiungi.TabIndex = 78;
            this.btnaggiungi.Text = "Aggiungi";
            this.btnaggiungi.UseVisualStyleBackColor = true;
            this.btnaggiungi.Click += new System.EventHandler(this.btnaggiungi_Click);
            // 
            // numQuantità
            // 
            this.numQuantità.Location = new System.Drawing.Point(708, 260);
            this.numQuantità.Name = "numQuantità";
            this.numQuantità.Size = new System.Drawing.Size(120, 20);
            this.numQuantità.TabIndex = 92;
            // 
            // numPrezzo
            // 
            this.numPrezzo.DecimalPlaces = 2;
            this.numPrezzo.Location = new System.Drawing.Point(708, 321);
            this.numPrezzo.Name = "numPrezzo";
            this.numPrezzo.Size = new System.Drawing.Size(120, 20);
            this.numPrezzo.TabIndex = 93;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(0, 0);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 94;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(601, 349);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 19);
            this.label1.TabIndex = 96;
            this.label1.Text = "Categoria";
            // 
            // cmbcategoria
            // 
            this.cmbcategoria.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbcategoria.FormattingEnabled = true;
            this.cmbcategoria.Location = new System.Drawing.Point(705, 355);
            this.cmbcategoria.Name = "cmbcategoria";
            this.cmbcategoria.Size = new System.Drawing.Size(121, 21);
            this.cmbcategoria.TabIndex = 98;
            // 
            // cmbcategoria2
            // 
            this.cmbcategoria2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbcategoria2.FormattingEnabled = true;
            this.cmbcategoria2.Location = new System.Drawing.Point(169, 119);
            this.cmbcategoria2.Name = "cmbcategoria2";
            this.cmbcategoria2.Size = new System.Drawing.Size(121, 21);
            this.cmbcategoria2.TabIndex = 99;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(81, 119);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 19);
            this.label6.TabIndex = 100;
            this.label6.Text = "Categoria";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::MarconiPieralisi.ElMerendero.WinApp.Properties.Resources.prodotti_nero_tras1;
            this.pictureBox4.Location = new System.Drawing.Point(528, 97);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(182, 82);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 97;
            this.pictureBox4.TabStop = false;
            // 
            // btnsalvautente
            // 
            this.btnsalvautente.BackColor = System.Drawing.Color.Transparent;
            this.btnsalvautente.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnsalvautente.BackgroundImage")));
            this.btnsalvautente.Location = new System.Drawing.Point(705, 406);
            this.btnsalvautente.Name = "btnsalvautente";
            this.btnsalvautente.Size = new System.Drawing.Size(32, 32);
            this.btnsalvautente.TabIndex = 82;
            this.btnsalvautente.Text = " ";
            this.btnsalvautente.UseVisualStyleBackColor = false;
            this.btnsalvautente.Click += new System.EventHandler(this.btnsalvautente_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(95, 91);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // FrmProdotti
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(848, 495);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cmbcategoria2);
            this.Controls.Add(this.cmbcategoria);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.numPrezzo);
            this.Controls.Add(this.numQuantità);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtdescrizione);
            this.Controls.Add(this.txtnomeprodotto);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblquantità);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnsalvautente);
            this.Controls.Add(this.btnaggiorna);
            this.Controls.Add(this.lsvprodotti);
            this.Controls.Add(this.btnelimina);
            this.Controls.Add(this.btnmodifica);
            this.Controls.Add(this.btnaggiungi);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "FrmProdotti";
            this.Text = "frmprodotti";
            this.Load += new System.EventHandler(this.FrmProdotti_Load);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numQuantità)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPrezzo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtdescrizione;
        private System.Windows.Forms.TextBox txtnomeprodotto;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblquantità;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnsalvautente;
        private System.Windows.Forms.Button btnaggiorna;
        private System.Windows.Forms.ListView lsvprodotti;
        private System.Windows.Forms.ColumnHeader tbnome;
        private System.Windows.Forms.ColumnHeader tbquantità;
        private System.Windows.Forms.ColumnHeader tbdescrizione;
        private System.Windows.Forms.ColumnHeader tbprezzo;
        private System.Windows.Forms.Button btnelimina;
        private System.Windows.Forms.Button btnmodifica;
        private System.Windows.Forms.Button btnaggiungi;
        private System.Windows.Forms.NumericUpDown numQuantità;
        private System.Windows.Forms.NumericUpDown numPrezzo;
        private System.Windows.Forms.ColumnHeader tbcategoria;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.ComboBox cmbcategoria;
        private System.Windows.Forms.ComboBox cmbcategoria2;
        private System.Windows.Forms.Label label6;
    }
}