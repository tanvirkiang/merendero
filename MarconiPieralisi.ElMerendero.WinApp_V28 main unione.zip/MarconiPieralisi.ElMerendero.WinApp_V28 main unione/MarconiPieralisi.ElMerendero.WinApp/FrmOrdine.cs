﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarconiPieralisi.ElMerendero.WinApp
{
    public partial class FrmOrdine : Form
    {
        List<ClsProdotto> prodotti = new List<ClsProdotto>();
        public FrmOrdine()
        {
            InitializeComponent();
           
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            
        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void FrmUtente_Load(object sender, EventArgs e)
        {
            //user control
            UcButtons ucb = new UcButtons();
            ucb.Dock = DockStyle.Left; // Per riempire lo spazio di sinistra
            ucb.BringToFront();  // Per portare i bottoni in primo piano
            this.Controls.Add(ucb); // Per aggiungere lo usercontrol alla form
            panel2.SendToBack(); // Per assicurarsi che lo usercontrol non finisca sopra al panello del titolo

            //carico le categorie dei prodotti
            /*Button bt1 = new Button();
            bt1.Name = "btPizza"; // In realtà il valore è dinamico preso dal foreach come già realizzato
            bt1.Tag = 3; // Qui inserisci l'ID della categoria del prodotto
            bt1.Text = "Pizza"; // Qui inserisci il nome del prodotto
            bt1.Location = new Point(X, Y);
            bt1.Click += new System.EventHandler(this.bt1_Click);
            this.Controls.Add(bt1); 
            loadCategorie(); */

        }
        private void bt1_Click(object sender, EventArgs e)
        {
            // Codice per caricare i prodotti della categoria del bottone (preleva l'ID dal tag)
        }
        private void loadProdotti()
        {
            

            ClsProdotto prodotto = new ClsProdotto();
            //prodotti = prodotto.getProdotti(); commentato perchè manca il parametro

            lsvprodotti.Items.Clear();
            foreach (var item in prodotti)
            {
                ListViewItem lvi = new ListViewItem(item.Nome);
                lvi.SubItems.Add(item.Prezzo.ToString());
                lvi.SubItems.Add(item.Quantita.ToString());

                lsvprodotti.Items.Add(lvi);
            }
        }

        private void loadCategorie()
        {


            ClsCategoria categoria = new ClsCategoria();
            List<ClsCategoria> categorie = categoria.getCategorie();
            int x = 310, y = 280;
            foreach (ClsCategoria cat in categorie)
            {
                Button btn = new Button();
                btn.Text = cat.nome;
                btn.Size = new Size(100, 50);
                btn.Location = new Point(x,y);
                y += 60;
                this.Controls.Add(btn);
            }

        }
        private void button5_Click(object sender, EventArgs e)
        {
            loadProdotti();
        }

        private void pnlordine_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnProdotti_Click(object sender, EventArgs e)
        {
            FrmProdotti f = new FrmProdotti();
            this.Hide();
            f.Show();
        }

        private void btnOrdini_Click(object sender, EventArgs e)
        {
            FrmOrdini f = new FrmOrdini();
            this.Hide();
            f.Show();
        }

        private void btnBrioches_Click(object sender, EventArgs e)
        {
            loadProdotti();
        }

        private void btnPizza_Click(object sender, EventArgs e)
        {
            loadProdotti();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void btnFocaccia_Click(object sender, EventArgs e)
        {
            loadProdotti();
        }

        private void btnBevande_Click(object sender, EventArgs e)
        {
            loadProdotti();
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void btnAggiungiOrdine_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void lsvprodotti_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
