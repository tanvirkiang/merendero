﻿namespace MarconiPieralisi.ElMerendero.WinApp
{
    partial class FrmUtentiAdm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmUtentiAdm));
            this.rbMerendero = new System.Windows.Forms.RadioButton();
            this.rbPersonaleScolastico = new System.Windows.Forms.RadioButton();
            this.rbAmministratore = new System.Windows.Forms.RadioButton();
            this.rbStudente = new System.Windows.Forms.RadioButton();
            this.btAggiorna = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cbClassiFIltro = new System.Windows.Forms.ComboBox();
            this.cbTipologiaFiltro = new System.Windows.Forms.ComboBox();
            this.lsvalunni = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnimportaalunni = new System.Windows.Forms.Button();
            this.btnelimina = new System.Windows.Forms.Button();
            this.btnmodifica = new System.Windows.Forms.Button();
            this.btnaggiungi = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.cbclasse = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbemail = new System.Windows.Forms.TextBox();
            this.tbcognome = new System.Windows.Forms.TextBox();
            this.tbnome = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btClearClasse = new System.Windows.Forms.Button();
            this.btClearTipologia = new System.Windows.Forms.Button();
            this.clearChecked = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btnsalvautente = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // rbMerendero
            // 
            this.rbMerendero.AutoSize = true;
            this.rbMerendero.Enabled = false;
            this.rbMerendero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbMerendero.Location = new System.Drawing.Point(770, 395);
            this.rbMerendero.Name = "rbMerendero";
            this.rbMerendero.Size = new System.Drawing.Size(113, 24);
            this.rbMerendero.TabIndex = 104;
            this.rbMerendero.TabStop = true;
            this.rbMerendero.Text = "Merendero";
            this.rbMerendero.UseVisualStyleBackColor = true;
            this.rbMerendero.CheckedChanged += new System.EventHandler(this.rbMerendero_CheckedChanged);
            // 
            // rbPersonaleScolastico
            // 
            this.rbPersonaleScolastico.AutoSize = true;
            this.rbPersonaleScolastico.Enabled = false;
            this.rbPersonaleScolastico.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbPersonaleScolastico.Location = new System.Drawing.Point(770, 372);
            this.rbPersonaleScolastico.Name = "rbPersonaleScolastico";
            this.rbPersonaleScolastico.Size = new System.Drawing.Size(192, 24);
            this.rbPersonaleScolastico.TabIndex = 103;
            this.rbPersonaleScolastico.TabStop = true;
            this.rbPersonaleScolastico.Text = "Personale scolastico";
            this.rbPersonaleScolastico.UseVisualStyleBackColor = true;
            this.rbPersonaleScolastico.CheckedChanged += new System.EventHandler(this.rbPersonaleScolastico_CheckedChanged);
            // 
            // rbAmministratore
            // 
            this.rbAmministratore.AutoSize = true;
            this.rbAmministratore.Enabled = false;
            this.rbAmministratore.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbAmministratore.Location = new System.Drawing.Point(770, 349);
            this.rbAmministratore.Name = "rbAmministratore";
            this.rbAmministratore.Size = new System.Drawing.Size(148, 24);
            this.rbAmministratore.TabIndex = 102;
            this.rbAmministratore.TabStop = true;
            this.rbAmministratore.Text = "Amministratore";
            this.rbAmministratore.UseVisualStyleBackColor = true;
            this.rbAmministratore.CheckedChanged += new System.EventHandler(this.rbAmministratore_CheckedChanged);
            // 
            // rbStudente
            // 
            this.rbStudente.AutoSize = true;
            this.rbStudente.Enabled = false;
            this.rbStudente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbStudente.Location = new System.Drawing.Point(770, 326);
            this.rbStudente.Name = "rbStudente";
            this.rbStudente.Size = new System.Drawing.Size(101, 24);
            this.rbStudente.TabIndex = 101;
            this.rbStudente.TabStop = true;
            this.rbStudente.Text = "Studente";
            this.rbStudente.UseVisualStyleBackColor = true;
            this.rbStudente.CheckedChanged += new System.EventHandler(this.rbStudente_CheckedChanged);
            // 
            // btAggiorna
            // 
            this.btAggiorna.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btAggiorna.Location = new System.Drawing.Point(475, 168);
            this.btAggiorna.Name = "btAggiorna";
            this.btAggiorna.Size = new System.Drawing.Size(72, 33);
            this.btAggiorna.TabIndex = 100;
            this.btAggiorna.Text = "Aggiorna";
            this.btAggiorna.UseVisualStyleBackColor = true;
            this.btAggiorna.Click += new System.EventHandler(this.btAggiorna_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(215, 153);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 19);
            this.label8.TabIndex = 99;
            this.label8.Text = "Tipologia";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(324, 154);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 19);
            this.label6.TabIndex = 98;
            this.label6.Text = "Classe";
            // 
            // cbClassiFIltro
            // 
            this.cbClassiFIltro.FormattingEnabled = true;
            this.cbClassiFIltro.Location = new System.Drawing.Point(328, 176);
            this.cbClassiFIltro.Name = "cbClassiFIltro";
            this.cbClassiFIltro.Size = new System.Drawing.Size(57, 21);
            this.cbClassiFIltro.TabIndex = 97;
            // 
            // cbTipologiaFiltro
            // 
            this.cbTipologiaFiltro.FormattingEnabled = true;
            this.cbTipologiaFiltro.Items.AddRange(new object[] {
            "Amministratore",
            "Studente",
            "Personale",
            "Merendero"});
            this.cbTipologiaFiltro.Location = new System.Drawing.Point(219, 175);
            this.cbTipologiaFiltro.Name = "cbTipologiaFiltro";
            this.cbTipologiaFiltro.Size = new System.Drawing.Size(76, 21);
            this.cbTipologiaFiltro.TabIndex = 96;
            // 
            // lsvalunni
            // 
            this.lsvalunni.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.lsvalunni.FullRowSelect = true;
            this.lsvalunni.HideSelection = false;
            this.lsvalunni.Location = new System.Drawing.Point(123, 207);
            this.lsvalunni.Name = "lsvalunni";
            this.lsvalunni.Size = new System.Drawing.Size(466, 366);
            this.lsvalunni.TabIndex = 89;
            this.lsvalunni.UseCompatibleStateImageBehavior = false;
            this.lsvalunni.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Nome";
            this.columnHeader1.Width = 98;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Cognome";
            this.columnHeader2.Width = 95;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Classe";
            this.columnHeader3.Width = 50;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Tipologia ";
            this.columnHeader4.Width = 59;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Email";
            this.columnHeader5.Width = 155;
            // 
            // btnimportaalunni
            // 
            this.btnimportaalunni.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnimportaalunni.Location = new System.Drawing.Point(605, 349);
            this.btnimportaalunni.Name = "btnimportaalunni";
            this.btnimportaalunni.Size = new System.Drawing.Size(95, 33);
            this.btnimportaalunni.TabIndex = 95;
            this.btnimportaalunni.Text = "Importa";
            this.btnimportaalunni.UseVisualStyleBackColor = true;
            this.btnimportaalunni.Click += new System.EventHandler(this.btnimportaalunni_Click);
            // 
            // btnelimina
            // 
            this.btnelimina.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnelimina.Location = new System.Drawing.Point(605, 291);
            this.btnelimina.Name = "btnelimina";
            this.btnelimina.Size = new System.Drawing.Size(95, 33);
            this.btnelimina.TabIndex = 94;
            this.btnelimina.Text = "Elimina";
            this.btnelimina.UseVisualStyleBackColor = true;
            this.btnelimina.Click += new System.EventHandler(this.btnelimina_Click);
            // 
            // btnmodifica
            // 
            this.btnmodifica.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmodifica.Location = new System.Drawing.Point(605, 229);
            this.btnmodifica.Name = "btnmodifica";
            this.btnmodifica.Size = new System.Drawing.Size(95, 33);
            this.btnmodifica.TabIndex = 93;
            this.btnmodifica.Text = "Modifica";
            this.btnmodifica.UseVisualStyleBackColor = true;
            this.btnmodifica.Click += new System.EventHandler(this.btnmodifica_Click);
            // 
            // btnaggiungi
            // 
            this.btnaggiungi.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaggiungi.Location = new System.Drawing.Point(605, 174);
            this.btnaggiungi.Name = "btnaggiungi";
            this.btnaggiungi.Size = new System.Drawing.Size(95, 33);
            this.btnaggiungi.TabIndex = 92;
            this.btnaggiungi.Text = "Aggiungi";
            this.btnaggiungi.UseVisualStyleBackColor = true;
            this.btnaggiungi.Click += new System.EventHandler(this.btnaggiungi_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(932, 308);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 19);
            this.label4.TabIndex = 91;
            this.label4.Text = "Classe:";
            // 
            // cbclasse
            // 
            this.cbclasse.BackColor = System.Drawing.Color.White;
            this.cbclasse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbclasse.Enabled = false;
            this.cbclasse.FormattingEnabled = true;
            this.cbclasse.Location = new System.Drawing.Point(915, 330);
            this.cbclasse.Name = "cbclasse";
            this.cbclasse.Size = new System.Drawing.Size(100, 21);
            this.cbclasse.TabIndex = 90;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(807, 469);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 19);
            this.label5.TabIndex = 88;
            this.label5.Text = "Salva";
            // 
            // tbemail
            // 
            this.tbemail.Enabled = false;
            this.tbemail.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbemail.Location = new System.Drawing.Point(842, 249);
            this.tbemail.Name = "tbemail";
            this.tbemail.Size = new System.Drawing.Size(204, 22);
            this.tbemail.TabIndex = 86;
            // 
            // tbcognome
            // 
            this.tbcognome.Enabled = false;
            this.tbcognome.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcognome.Location = new System.Drawing.Point(842, 209);
            this.tbcognome.Name = "tbcognome";
            this.tbcognome.Size = new System.Drawing.Size(204, 22);
            this.tbcognome.TabIndex = 85;
            // 
            // tbnome
            // 
            this.tbnome.Enabled = false;
            this.tbnome.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbnome.Location = new System.Drawing.Point(842, 170);
            this.tbnome.Name = "tbnome";
            this.tbnome.Size = new System.Drawing.Size(204, 22);
            this.tbnome.TabIndex = 84;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(731, 250);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 19);
            this.label3.TabIndex = 83;
            this.label3.Text = "Email:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(731, 170);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 19);
            this.label2.TabIndex = 82;
            this.label2.Text = "Nome:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(731, 210);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 19);
            this.label1.TabIndex = 81;
            this.label1.Text = "Cognome:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel2.Controls.Add(this.pictureBox3);
            this.panel2.Controls.Add(this.pictureBox4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1143, 91);
            this.panel2.TabIndex = 107;
            // 
            // btClearClasse
            // 
            this.btClearClasse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btClearClasse.Location = new System.Drawing.Point(391, 176);
            this.btClearClasse.Name = "btClearClasse";
            this.btClearClasse.Size = new System.Drawing.Size(13, 21);
            this.btClearClasse.TabIndex = 112;
            this.btClearClasse.Text = "X";
            this.btClearClasse.UseVisualStyleBackColor = true;
            this.btClearClasse.Click += new System.EventHandler(this.btClearClasse_Click);
            // 
            // btClearTipologia
            // 
            this.btClearTipologia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btClearTipologia.Location = new System.Drawing.Point(301, 175);
            this.btClearTipologia.Name = "btClearTipologia";
            this.btClearTipologia.Size = new System.Drawing.Size(13, 21);
            this.btClearTipologia.TabIndex = 113;
            this.btClearTipologia.Text = "X";
            this.btClearTipologia.UseVisualStyleBackColor = true;
            this.btClearTipologia.Click += new System.EventHandler(this.btClearTipologia_Click);
            // 
            // clearChecked
            // 
            this.clearChecked.Enabled = false;
            this.clearChecked.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearChecked.Location = new System.Drawing.Point(735, 355);
            this.clearChecked.Name = "clearChecked";
            this.clearChecked.Size = new System.Drawing.Size(13, 21);
            this.clearChecked.TabIndex = 118;
            this.clearChecked.Text = "X";
            this.clearChecked.UseVisualStyleBackColor = true;
            this.clearChecked.Click += new System.EventHandler(this.clearChecked_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gray;
            this.label7.Location = new System.Drawing.Point(839, 153);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(176, 13);
            this.label7.TabIndex = 119;
            this.label7.Text = "I campi con * sono obbligatori";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Gray;
            this.label9.Location = new System.Drawing.Point(825, 174);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(12, 13);
            this.label9.TabIndex = 120;
            this.label9.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Gray;
            this.label10.Location = new System.Drawing.Point(826, 214);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(12, 13);
            this.label10.TabIndex = 121;
            this.label10.Text = "*";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Gray;
            this.label11.Location = new System.Drawing.Point(825, 254);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(12, 13);
            this.label11.TabIndex = 122;
            this.label11.Text = "*";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(731, 291);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 19);
            this.label12.TabIndex = 123;
            this.label12.Text = "Tipologia:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Gray;
            this.label13.Location = new System.Drawing.Point(822, 295);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(12, 13);
            this.label13.TabIndex = 124;
            this.label13.Text = "*";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::MarconiPieralisi.ElMerendero.WinApp.Properties.Resources.utenti_nero_tras1;
            this.pictureBox2.Location = new System.Drawing.Point(397, 93);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(125, 69);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 114;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(99, 123);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(50, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 8;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(290, -68);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(232, 238);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(0, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(95, 91);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // btnsalvautente
            // 
            this.btnsalvautente.BackColor = System.Drawing.Color.Transparent;
            this.btnsalvautente.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnsalvautente.BackgroundImage")));
            this.btnsalvautente.Enabled = false;
            this.btnsalvautente.Location = new System.Drawing.Point(770, 463);
            this.btnsalvautente.Name = "btnsalvautente";
            this.btnsalvautente.Size = new System.Drawing.Size(32, 32);
            this.btnsalvautente.TabIndex = 87;
            this.btnsalvautente.Text = " ";
            this.btnsalvautente.UseVisualStyleBackColor = false;
            this.btnsalvautente.Click += new System.EventHandler(this.btnsalvautente_Click);
            // 
            // FrmUtentiAdm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1143, 696);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.clearChecked);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btClearTipologia);
            this.Controls.Add(this.btClearClasse);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.rbMerendero);
            this.Controls.Add(this.rbPersonaleScolastico);
            this.Controls.Add(this.rbAmministratore);
            this.Controls.Add(this.rbStudente);
            this.Controls.Add(this.btAggiorna);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cbClassiFIltro);
            this.Controls.Add(this.cbTipologiaFiltro);
            this.Controls.Add(this.lsvalunni);
            this.Controls.Add(this.btnimportaalunni);
            this.Controls.Add(this.btnelimina);
            this.Controls.Add(this.btnmodifica);
            this.Controls.Add(this.btnaggiungi);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbclasse);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnsalvautente);
            this.Controls.Add(this.tbemail);
            this.Controls.Add(this.tbcognome);
            this.Controls.Add(this.tbnome);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmUtentiAdm";
            this.Text = "FrmUtentiAdm";
            this.Load += new System.EventHandler(this.FrmUtentiAdm_Load);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbMerendero;
        private System.Windows.Forms.RadioButton rbPersonaleScolastico;
        private System.Windows.Forms.RadioButton rbAmministratore;
        private System.Windows.Forms.RadioButton rbStudente;
        private System.Windows.Forms.Button btAggiorna;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbClassiFIltro;
        private System.Windows.Forms.ComboBox cbTipologiaFiltro;
        private System.Windows.Forms.ListView lsvalunni;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.Button btnimportaalunni;
        private System.Windows.Forms.Button btnelimina;
        private System.Windows.Forms.Button btnmodifica;
        private System.Windows.Forms.Button btnaggiungi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbclasse;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnsalvautente;
        private System.Windows.Forms.TextBox tbemail;
        private System.Windows.Forms.TextBox tbcognome;
        private System.Windows.Forms.TextBox tbnome;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button btClearClasse;
        private System.Windows.Forms.Button btClearTipologia;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button clearChecked;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
    }
}